


exports.run=async (event)=>{
    // event content structure:
    // https://docs.aws.amazon.com/AmazonS3/latest/dev/notification-content-structure.html

    console.log('hello from lambda')
}

